package com.health.openscale.constants;

public class Constantes {
    //public static final String SERVER_PATH = "https://192.168.1.6:8181/projectTTMealPlan/";
    public static final String SERVER_PATH = "http://192.168.1.6:8080/projectTTMealPlan/";
    public static final String paciente = "pacienteSharedPreference";
}
